<?php
/**
 * โปรแกรมเช็คชื่อ แสดงพิกัดและเวลา (เวอร์ชันเว็บ)
 * Program for checking name, displaying coordinates and time (Web Version)
 */

// ตั้งค่า encoding
header('Content-Type: text/html; charset=UTF-8');

/**
 * เช็คชื่อว่าถูกต้องหรือไม่
 */
function checkName($name) {
    $name = trim($name);
    
    if (empty($name)) {
        return [false, "ชื่อไม่สามารถว่างได้"];
    }
    
    if (strlen($name) < 2) {
        return [false, "ชื่อต้องมีอย่างน้อย 2 ตัวอักษร"];
    }
    
    if (strlen($name) > 50) {
        return [false, "ชื่อยาวเกินไป (สูงสุด 50 ตัวอักษร)"];
    }
    
    if (!preg_match('/[a-zA-Zก-๙]/u', $name)) {
        return [false, "ชื่อต้องมีตัวอักษรอย่างน้อย 1 ตัว"];
    }
    
    return [true, "ชื่อถูกต้อง"];
}

/**
 * ดึงเวลาปัจจุบัน
 */
function getCurrentTime() {
    $now = new DateTime();
    $timeShort = $now->format('Y-m-d H:i:s');
    
    setlocale(LC_TIME, 'th_TH.UTF-8');
    $timeLong = strftime('%A, %d %B %Y, %I:%M:%S %p', $now->getTimestamp());
    
    if ($timeLong === false) {
        $timeLong = $now->format('l, d F Y, h:i:s A');
    }
    
    return [$timeShort, $timeLong];
}

/**
 * ดึงพิกัดจาก IP address
 */
function getLocationCoordinates() {
    try {
        $url = "http://ip-api.com/json/";
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            return [
                'latitude' => 'N/A',
                'longitude' => 'N/A',
                'city' => 'N/A',
                'country' => 'N/A',
                'region' => 'N/A',
                'timezone' => 'N/A',
                'success' => false,
                'error' => 'ไม่สามารถเชื่อมต่ออินเทอร์เน็ตได้: ' . $error
            ];
        }
        
        if ($httpCode !== 200) {
            return [
                'latitude' => 'N/A',
                'longitude' => 'N/A',
                'city' => 'N/A',
                'country' => 'N/A',
                'region' => 'N/A',
                'timezone' => 'N/A',
                'success' => false,
                'error' => 'ไม่สามารถดึงข้อมูลได้ (HTTP ' . $httpCode . ')'
            ];
        }
        
        $data = json_decode($response, true);
        
        if ($data && isset($data['status']) && $data['status'] === 'success') {
            return [
                'latitude' => isset($data['lat']) ? $data['lat'] : 'N/A',
                'longitude' => isset($data['lon']) ? $data['lon'] : 'N/A',
                'city' => isset($data['city']) ? $data['city'] : 'N/A',
                'country' => isset($data['country']) ? $data['country'] : 'N/A',
                'region' => isset($data['regionName']) ? $data['regionName'] : 'N/A',
                'timezone' => isset($data['timezone']) ? $data['timezone'] : 'N/A',
                'success' => true
            ];
        } else {
            return [
                'latitude' => 'N/A',
                'longitude' => 'N/A',
                'city' => 'N/A',
                'country' => 'N/A',
                'region' => 'N/A',
                'timezone' => 'N/A',
                'success' => false,
                'error' => 'ไม่สามารถดึงข้อมูลได้'
            ];
        }
    } catch (Exception $e) {
        return [
            'latitude' => 'N/A',
            'longitude' => 'N/A',
            'city' => 'N/A',
            'country' => 'N/A',
            'region' => 'N/A',
            'timezone' => 'N/A',
            'success' => false,
            'error' => 'เกิดข้อผิดพลาด: ' . $e->getMessage()
        ];
    }
}

$name = isset($_POST['name']) ? $_POST['name'] : '';
$result = null;
$timeInfo = null;
$location = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($name)) {
    list($isValid, $message) = checkName($name);
    $result = ['valid' => $isValid, 'message' => $message];
    
    if ($isValid) {
        $timeInfo = getCurrentTime();
        $location = getLocationCoordinates();
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เช็คชื่อ แสดงพิกัดและเวลา</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            padding: 40px;
        }
        
        h1 {
            color: #333;
            text-align: center;
            margin-bottom: 10px;
            font-size: 28px;
        }
        
        .subtitle {
            text-align: center;
            color: #666;
            margin-bottom: 30px;
            font-size: 14px;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
        }
        
        input[type="text"] {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        
        input[type="text"]:focus {
            outline: none;
            border-color: #667eea;
        }
        
        button {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        
        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        
        button:active {
            transform: translateY(0);
        }
        
        .result-box {
            margin-top: 30px;
            padding: 25px;
            background: #f8f9fa;
            border-radius: 10px;
            border-left: 4px solid #667eea;
        }
        
        .result-box h2 {
            color: #333;
            margin-bottom: 20px;
            font-size: 22px;
        }
        
        .info-item {
            margin-bottom: 15px;
            padding: 12px;
            background: white;
            border-radius: 6px;
            border-left: 3px solid #667eea;
        }
        
        .info-label {
            font-weight: 600;
            color: #555;
            margin-bottom: 5px;
        }
        
        .info-value {
            color: #333;
            font-size: 18px;
        }
        
        .error {
            background: #fee;
            border-left-color: #f44336;
            color: #c62828;
            padding: 15px;
            border-radius: 6px;
            margin-top: 20px;
        }
        
        .success {
            background: #e8f5e9;
            border-left-color: #4caf50;
            color: #2e7d32;
            padding: 15px;
            border-radius: 6px;
            margin-top: 20px;
        }
        
        .coordinates-box {
            background: #e3f2fd;
            padding: 15px;
            border-radius: 8px;
            margin: 15px 0;
            border-left: 4px solid #2196f3;
        }
        
        .map-link {
            display: inline-block;
            margin-top: 10px;
            padding: 10px 20px;
            background: #2196f3;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            transition: background 0.3s;
        }
        
        .map-link:hover {
            background: #1976d2;
        }
        
        .summary {
            margin-top: 30px;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 10px;
        }
        
        .summary h3 {
            margin-bottom: 15px;
        }
        
        .summary-item {
            margin: 10px 0;
            padding: 8px;
            background: rgba(255,255,255,0.1);
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>📍 เช็คชื่อ แสดงพิกัดและเวลา</h1>
        <p class="subtitle">Name Check, Coordinates and Time Display Program</p>
        
        <form method="POST" action="">
            <div class="form-group">
                <label for="name">กรุณากรอกชื่อของคุณ (Please enter your name):</label>
                <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>" required>
            </div>
            <button type="submit">ตรวจสอบ (Check)</button>
        </form>
        
        <?php if ($result): ?>
            <div class="<?php echo $result['valid'] ? 'success' : 'error'; ?>">
                <strong>ผลการเช็คชื่อ (Name Check Result):</strong> <?php echo htmlspecialchars($result['message']); ?>
            </div>
            
            <?php if ($result['valid'] && $timeInfo && $location): ?>
                <div class="result-box">
                    <h2>⏰ เวลา (Time)</h2>
                    <div class="info-item">
                        <div class="info-label">เวลาปัจจุบัน (Current Time):</div>
                        <div class="info-value"><?php echo htmlspecialchars($timeInfo[0]); ?></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">รูปแบบเต็ม (Full Format):</div>
                        <div class="info-value"><?php echo htmlspecialchars($timeInfo[1]); ?></div>
                    </div>
                </div>
                
                <div class="result-box">
                    <h2>📍 พิกัด (Coordinates)</h2>
                    
                    <div class="coordinates-box">
                        <div class="info-label">ละติจูด (Latitude):</div>
                        <div class="info-value"><?php echo htmlspecialchars($location['latitude']); ?>°</div>
                    </div>
                    
                    <div class="coordinates-box">
                        <div class="info-label">ลองจิจูด (Longitude):</div>
                        <div class="info-value"><?php echo htmlspecialchars($location['longitude']); ?>°</div>
                    </div>
                    
                    <div class="info-item">
                        <div class="info-label">พิกัดแบบเต็ม (Full Coordinates):</div>
                        <div class="info-value">(<?php echo htmlspecialchars($location['latitude']); ?>, <?php echo htmlspecialchars($location['longitude']); ?>)</div>
                    </div>
                    
                    <div class="info-item">
                        <div class="info-label">เมือง (City):</div>
                        <div class="info-value"><?php echo htmlspecialchars($location['city']); ?></div>
                    </div>
                    
                    <div class="info-item">
                        <div class="info-label">จังหวัด/รัฐ (Region):</div>
                        <div class="info-value"><?php echo htmlspecialchars($location['region']); ?></div>
                    </div>
                    
                    <div class="info-item">
                        <div class="info-label">ประเทศ (Country):</div>
                        <div class="info-value"><?php echo htmlspecialchars($location['country']); ?></div>
                    </div>
                    
                    <div class="info-item">
                        <div class="info-label">เขตเวลา (Timezone):</div>
                        <div class="info-value"><?php echo htmlspecialchars($location['timezone']); ?></div>
                    </div>
                    
                    <?php if ($location['success'] && $location['latitude'] !== 'N/A' && $location['longitude'] !== 'N/A'): ?>
                        <a href="https://www.google.com/maps?q=<?php echo urlencode($location['latitude']); ?>,<?php echo urlencode($location['longitude']); ?>" target="_blank" class="map-link">
                            เปิด Google Maps 🗺️
                        </a>
                    <?php endif; ?>
                </div>
                
                <div class="summary">
                    <h3>📋 สรุปข้อมูล (Summary)</h3>
                    <div class="summary-item">
                        <strong>ชื่อ (Name):</strong> <?php echo htmlspecialchars($name); ?>
                    </div>
                    <div class="summary-item">
                        <strong>เวลา (Time):</strong> <?php echo htmlspecialchars($timeInfo[0]); ?>
                    </div>
                    <?php if ($location['success']): ?>
                        <div class="summary-item">
                            <strong>ละติจูด (Latitude):</strong> <?php echo htmlspecialchars($location['latitude']); ?>°
                        </div>
                        <div class="summary-item">
                            <strong>ลองจิจูด (Longitude):</strong> <?php echo htmlspecialchars($location['longitude']); ?>°
                        </div>
                        <div class="summary-item">
                            <strong>พิกัด (Coordinates):</strong> (<?php echo htmlspecialchars($location['latitude']); ?>, <?php echo htmlspecialchars($location['longitude']); ?>)
                        </div>
                        <div class="summary-item">
                            <strong>สถานที่ (Location):</strong> <?php echo htmlspecialchars($location['city']); ?>, <?php echo htmlspecialchars($location['country']); ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</body>
</html>



